<link rel="stylesheet" href="{{ asset('front-end-assets/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('front-end-assets/css/bootstrap-select.css') }}">

<link href="{{ asset('front-end-assets/css/style.css') }}" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="{{ asset('front-end-assets/css/flexslider.css') }}" type="text/css" media="screen" />
<link rel="stylesheet" href="{{ asset('front-end-assets/css/font-awesome.min.css') }}" />

<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

<link href="{{ asset('front-end-assets/css/jquery.uls.css') }}" rel="stylesheet"/>
<link href="{{ asset('front-end-assets/css/jquery.uls.grid.css') }}" rel="stylesheet"/>
<link href="{{ asset('front-end-assets/css/jquery.uls.lcd.css') }}" rel="stylesheet"/>

<link rel="stylesheet" type="text/css" href="{{ asset('front-end-assets/slick/slick.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('front-end-assets/slick/slick-theme.css')}}">

{{-- <link href="{{ asset('front-end-assets/custom-css/main-menu.css') }}" rel="stylesheet"/> --}}
<link href="{{ asset('front-end-assets/custom-css/menu.css') }}" rel="stylesheet" media="all" />
